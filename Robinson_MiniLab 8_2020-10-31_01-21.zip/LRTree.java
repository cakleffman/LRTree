public class LRTree {
    
    private Node root;
    
    private class Node {
        private String data;
        private Node left;
        private Node right;
        
        private Node(String data, Node left, Node right) {
            this.data = data;
            this.left = left;
            this.right = right;
        }
    }
    
    public LRTree() {
        this.root = new Node("-", null, null);
    }
    
    // Adds the string s to the tree in the proper location, as described in the PDF.
    // Also adds the necessary parent nodes, as described in the PDF.
    // If the string already exists in the tree, or if the string contains characters
    // that are not L or R, do nothing.
    public void add(String s) {
        
        Node currentNode = root;
       
        for(int i = 0; i < s.length(); i++){
            if(s.charAt(i) != 'L' && s.charAt(i) != 'R'){
                System.out.println("Invalid string.");
                return;
            }
            if(s.charAt(i) == 'L' && currentNode.left == null){
                Node left = new Node(s.substring(0, i + 1), null, null);
                currentNode.left = left;
                currentNode = currentNode.left;
            }
            else if(s.charAt(i) == 'R' && currentNode.right == null){
                Node right = new Node(s.substring(0, i + 1), null, null);
                currentNode.right = right;
                currentNode = currentNode.right;
            }
            else if(currentNode.left != null && s.charAt(i) == 'L'){
                currentNode = currentNode.left;
            }
            else if(currentNode.right != null && s.charAt(i) == 'R'){
                currentNode = currentNode.right;
            }
            
        }
        
    
    }
    
    // Returns whether or not the String s is found within the tree.
    public boolean contains(String s) {
        Node currentNode = root;
        int i = 0;
        while(i < s.length() && currentNode != null){
            if(s.charAt(i) == 'L'){
                currentNode = currentNode.left;
            }
            if(s.charAt(i) == 'R'){
                currentNode = currentNode.right;
            }
            
            i++;
        }
        
        if(currentNode == null){
            return false;
        }
        else{
            return true;
        }
        
    }
    
    // Prints the tree in the sideways orientation described in the PDF.
    public void print() {
        printHelper(root, 0);
    }
    
    // Recursive helper method for print().
    public void printHelper(Node n, int depth) {
        if (n == null) {
            return;
        }
        
        printHelper(n.right, depth + 1);

        String tabs = "";
        for (int i = 0; i < depth; i++) {
            tabs += "\t";
        }
        System.out.println(tabs + n.data);

        printHelper(n.left, depth + 1);
    }
    
    public static void main(String[] args) {
        // Show us that it works!!
        LRTree myTree = new LRTree();
        
        //adds nodes to my tree
        myTree.add("R");
        myTree.add("RR");
        myTree.add("LLRL");
        
        //Prints true if the string is in the tree && false otherwise
        System.out.println(myTree.contains("L"));
        
        //prints my tree
        myTree.print();
    }
}